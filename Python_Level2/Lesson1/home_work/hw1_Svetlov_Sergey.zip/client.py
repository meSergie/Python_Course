import socket
#import lib
import sys

addr = sys.argv[1]
port = int(sys.argv[2])
print(str(addr), port)
sock = socket.socket(
        family = socket.AF_INET,
        type = socket.SOCK_STREAM,
        proto = 0)

sock.connect((addr, port))# (("127.0.0.1", 7777))
#lib.main_loop_for_client(sock)
timestr = sock.recv(1024)
print(timestr.decode('ascii'))
sock.close()
